import { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { ProductDetailClient } from '../../../components/products/ProductDetailClient';
import { ProductCard } from '../../../components/products/ProductCard';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';

async function getProduct(id: string) {
  try {
    const res = await fetch(
      `${process.env.NEXT_PUBLIC_API_URL}/products/${id}`,
      { next: { revalidate: 300 } },
    );
    if (!res.ok) return null;
    const data = await res.json();
    return data.data || data;
  } catch {
    return null;
  }
}

async function getRelated(category: string, excludeId: string) {
  try {
    const res = await fetch(
      `${process.env.NEXT_PUBLIC_API_URL}/products?category=${encodeURIComponent(category)}&limit=4`,
      { next: { revalidate: 300 } },
    );
    const data = await res.json();
    return (data.data || []).filter((p: any) => p._id !== excludeId);
  } catch {
    return [];
  }
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}): Promise<Metadata> {
  const { id } = await params;
  const product = await getProduct(id);
  if (!product) return { title: 'Product — Royce Lighting' };
  return {
    title: `${product.name} — Royce Lighting`,
    description: product.description?.substring(0, 160) || `${product.name} — Handcrafted luxury lighting by Royce.`,
  };
}

export default async function ProductDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const product = await getProduct(id);
  if (!product) notFound();

  const related = await getRelated(product.category, id);

  return (
    <div>
      <ProductDetailClient product={product} />

      {/* Related products */}
      {related.length > 0 && (
        <section style={{ padding: '6rem 1.5rem 8rem', background: 'var(--charcoal-2)', borderTop: '1px solid rgba(250,247,240,0.06)' }}>
          <div className="max-w-7xl mx-auto">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '3.5rem', flexWrap: 'wrap', gap: '1rem' }}>
              <div>
                <p className="overline-text" style={{ marginBottom: '0.875rem' }}>You May Also Like</p>
                <h2 style={{ fontFamily: "'Playfair Display',serif", fontSize: 'clamp(1.5rem,3vw,2.5rem)', fontWeight: 300, fontStyle: 'italic', color: 'var(--ivory)' }}>
                  Related Pieces
                </h2>
              </div>
              <Link
                href={`/shop?category=${product.category}`}
                style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.6rem', letterSpacing: '0.2em', textTransform: 'uppercase', color: 'var(--gold)', textDecoration: 'none' }}
              >
                View All <ArrowRight size={12} />
              </Link>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '1px', background: 'rgba(250,247,240,0.04)' }}
              className="max-lg:grid-cols-3 max-md:grid-cols-2 max-sm:grid-cols-1">
              {related.slice(0, 4).map((p: any) => (
                <ProductCard key={p._id} product={p} />
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
